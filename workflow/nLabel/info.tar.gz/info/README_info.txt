Os arquivos do diretório atual tiveram seus nomes padronizados e o conteúdo
consiste na junção de diferentes arquivos do /data referentes ao mesmo filme.

The files contain information about tweets localization separated by state, country
and the address field concatenates the whole address info.
